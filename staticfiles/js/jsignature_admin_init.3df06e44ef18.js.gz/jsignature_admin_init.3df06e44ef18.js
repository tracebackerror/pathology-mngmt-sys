if (django && django.jQuery) {
  var jQuery = django.jQuery;
  var $ = django.jQuery;
}
